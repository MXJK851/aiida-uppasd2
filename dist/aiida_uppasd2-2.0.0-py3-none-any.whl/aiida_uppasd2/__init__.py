"""
aiida_uppasd2

AiiDA plugin for UppASD version 2.0.0
"""

__version__ = "2.0.0"
